#include "header.h"
double read_double(FILE* infile) // Reads one double precision number from the input file.Note: You may assume that the file only contains real numbers.
{
	double read_num;
	fscanf(infile, "%lf", &read_num);
	return read_num;
}


int read_integer(FILE* infile) // Reads one integer number from the input file.
{
	int read_int;
	fscanf(infile, "%d", &read_int);
	return read_int;
}


double calculate_sum(double number1, double number2, double number3, double number4, double number5) // Finds the sum of number1, number2, number3, number4, and number5and returns the result.
{
	return number1 + number2 + number3 + number4 + number5;
}


double calculate_mean(double sum, int number) //Determines the mean through the calculation sum / number and returns the result.You need to check to make sure that number is not 0. If it is 0 the function returns - 1.0 (we will assume that we are calculating the mean of positive numbers), otherwise it returns the mean.
{
	double mean;
	mean = sum / number;
	if (number == 0)
	{
		return -1;
	}
	else 
	{
		return mean;
	}
	
}


double calculate_deviation(double number, double mean) // Determines the deviation of number from the meanand returns the result.The deviation may be calculated as number - mean.
{
	double deviation;
	deviation = number - mean;
	return deviation;
}


double calculate_variance(double deviation1, double deviation2, double deviation3, double deviation4, double deviation5, int number) // Determines the variance through the calculation : ((deviation1) ^ 2 + (deviation2) ^ 2 + (deviation3) ^ 2 + (deviation4) ^ 2 + (deviation5) ^ 2) / number and returns the result.Hint : you may call your calculate_mean() function to determine the result.
{
	double sum, variance;
	sum = (deviation1 * deviation1) + (deviation2 * deviation2) + (deviation3 * deviation3) + (deviation4 * deviation4) + (deviation5 * deviation5);
	variance = calculate_mean(sum, number);
	return variance;
}


double calculate_standard_deviation(double variance) // Calculates the standard deviation as sqrt(variance) and returns the result.Recall that you may use the sqrt() function that is found in math.h.
{
	return sqrt(variance);
}

//Determines the minimum number out of the five input parameters passed into the function, returning to min
double find_max(double number1, double number2, double number3, double number4, double number5) // Determines the maximum number out of the five input parameters passed into the function, returning the max.
{
	double king = number1; //declare variables, set ewual to number 1 
	if (number2 >= king)// "king of the hill", maximum number will naturally stay in highest varivable when compared to each number 
	{
		king = number2;
	}
	if (number3 >= king)
	{
		king = number3;
	}
	if (number4 >= king)
	{
		king = number4;
	}
	if (number5 >= king)
	{
		king = number5;
	}
	return king;
}


double find_min(double number1, double number2, double number3, double number4, double number5) //Determines the minimum number out of the five input parameters passed into the function, returning the min.
{
	double king = number1;
	if (king >= number2)
	{
		king = number2;
	}
	if (king >= number3)
	{
		king = number3;
	}
	if (king >= number4)
	{
		king = number4;
	}
	if (king >= number5)
	{
		king = number5;
	}
	else
	{
		return 0;
	}
	return king;
}


void print_double(FILE* outfile, double number) // Prints a double precision number(to the hundredths place) to an output file
{
	fprintf(outfile, "%.2lf\n", number);
	return number;
}