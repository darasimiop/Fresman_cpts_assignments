#include "header.h"

int main(void) {
	FILE* infile = fopen("input.dat", "r");
	FILE* outfile = fopen("output.dat", "a");
//declaring most if not all the varibles being used
	double gpa1 = 0.0, gpa2 = 0.0, gpa3 = 0.0, gpa4 = 0.0, gpa5 = 0.0, age1 = 0.0, age2 = 0.0, age3 = 0.0, age4 = 0.0, age5 = 0.0; 
	int number1 = 0, number2 = 0, number3 = 0, number4 = 0, number5 = 0, classstanding1 = 0, classstanding2 = 0, classstanding3 = 0, classstanding4 = 0, classstanding5 = 0;

	//reading integers in the "input.dat" file in order by calling the functions we created 
	number1 = read_integer(infile);
	gpa1 = read_double(infile);
	classstanding1 = read_integer(infile);
	age1 = read_double(infile);

	number2 = read_integer(infile);
	gpa2 = read_double(infile);
	classstanding2 = read_integer(infile);
	age2 = read_double(infile);

	number3 = read_integer(infile);
	gpa3 = read_double(infile);
	classstanding3 = read_integer(infile);
	age3 = read_double(infile);

	number4 = read_integer(infile);
	gpa4 = read_double(infile);
	classstanding4 = read_integer(infile);
	age4 = read_double(infile);

	number5 = read_integer(infile);
	gpa5 = read_double(infile);
	classstanding5 = read_integer(infile);
	age5 = read_double(infile);
	//Printinf those numbers, originally used as  a test 
	printf("%d\n", number1);
	printf("%lf\n", gpa1);
	printf("%d\n", classstanding1);
	printf("%lf\n\n", age1);

	printf("%d\n", number2);
	printf("%lf\n", gpa2);
	printf("%d\n", classstanding2);
	printf("%lf\n\n", age2);

	printf("%d\n", number3);
	printf("%lf\n", gpa3);
	printf("%d\n", classstanding3);
	printf("%lf\n\n", age3);

	printf("%d\n", number4);
	printf("%lf\n", gpa4);
	printf("%d\n", classstanding4);
	printf("%lf\n\n", age4);

	printf("%d\n", number5);
	printf("%lf\n", gpa5);
	printf("%d\n", classstanding5);
	printf("%lf\n\n", age5);
	
	
	//Calculates the sum of the GPAs;
	double gpa_sum = calculate_sum(gpa1, gpa2, gpa3, gpa4, gpa5);

	//Calculates the sum of the class standings;
	double classstanding_sum = calculate_sum(classstanding1, classstanding2, classstanding3, classstanding4, classstanding5);

	//Calculates the sum of the ages;
	double age_sum = calculate_sum(age1, age2, age3, age4, age5);


	//Calculates the mean of the GPAs, writing the result to the output file(output.dat);
	double gpa_mean = calculate_mean(gpa_sum, 5);	
	print_double(outfile, gpa_mean);
	//Calculates the mean of the class standings, writing the result to the output file(output.dat);
	double classstanding_mean = 0.0;
	classstanding_mean = calculate_mean(classstanding_sum, 5);
	print_double(outfile, classstanding_mean);
	//Calculates the mean of the ages, writing the result to the output file(output.dat);
	double age_mean = 0.0;
	age_mean = calculate_mean(age_sum, 5);//printing to "output.dat", sum_mean
	print_double(outfile, age_mean);//Creating line space in "output.dat"


	//Calculates the deviation of each GPA from the mean(Hint: need to call calculate_deviation() 5 times)
	double deviation1 = 0.0, deviation2 = 0.0, deviation3 = 0.0, deviation4 = 0.0, deviation5 = 0.0;
	deviation1 = calculate_deviation(gpa1, gpa_mean);
	deviation2 = calculate_deviation(gpa2, gpa_mean);
	deviation3 = calculate_deviation(gpa3, gpa_mean);
	deviation4 = calculate_deviation(gpa4, gpa_mean);
	deviation5 = calculate_deviation(gpa5, gpa_mean);


		//Calculates the variance of the GPAs
	double variance_gpa = 0.0;
	variance_gpa = calculate_variance(deviation1, deviation2, deviation3, deviation4, deviation5, 5);
		//Calculates the standard deviation of the GPAs, writing the result to the output file(output.dat);
		double stand_deviation = 0.0;
		stand_deviation = calculate_standard_deviation(variance_gpa);
		print_double(outfile, stand_deviation);

	//Determines the min of the GPAs, writing the result to the output file(output.dat);
		double min_gpa = 0.0;
		min_gpa = find_min(gpa1, gpa2, gpa3, gpa4, gpa5);
		print_double(outfile, min_gpa);

	//Determines the max of the GPAs, writing the result to the output file(output.dat);
		double max_gpa = find_max(gpa1, gpa2, gpa3, gpa4, gpa5);
		print_double(outfile, max_gpa);
		printf("\n%lf", max_gpa);


	//Closes the inputand output files(i.e.input.dat and output.dat)
		fclose(infile);
		fclose(outfile);

		return 0;

}