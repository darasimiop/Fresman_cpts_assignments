#include "fitbit.h"

int main() {
	


	FILE* infile = fopen("FitbitData.csv", "r"),
	    *outfile = fopen("Results.csv", "w");
	FitbitData fitbitArray[MAXROWS]; //max rows = 1440 to represent max number of rows accepted by the array.

	int isdatafilled = fillData(infile, &fitbitArray);

	//paitent checker.
	int ispaiteintchecked = paitentChecker(&fitbitArray);
	// row modifier //checks for duplicate minute.
	int minuteVerifier = minutechecker(&fitbitArray);

	printStruct(&fitbitArray);


	//all calculations:
	//calories
	//floors
	//steps
	//heartRate
	//maxsteps
	//poorsleeptally.
	double Distance = calculateDistance(&fitbitArray);


	printSructToFile(outfile, &fitbitArray);




	
	return 0;
}