// Darasimi Ogunbinu-Peters
// PA 8 - Data Analysis via BST
#include "DataAnalysis.h"

int main()
{
	DataAnalysis obj;
	obj.runAnalysis();
	return 0;
}